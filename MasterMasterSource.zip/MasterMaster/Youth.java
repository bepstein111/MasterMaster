import java.util.ArrayList;
public class Youth
{
	private String myFirst, myLast, myTYG, myPosition, myGender;
	private ArrayList<String> myAssignments;
	public Youth(String first, String last, String gender, String tyg, String position)
	{
		myFirst = first;
		myLast = last;
		myGender = gender;
		myTYG = tyg;
		myPosition = position;
		myAssignments = new ArrayList<String>();
	}
	public String gender()
	{
		return myGender;
	}
	public void addAssignment(String toAdd)
	{
		myAssignments.add(toAdd);
	}
	public String getFirstN()
	{
		return myFirst;
	}
	public String getLastN()
	{
		return myLast;
	}
	public String getTYG()
	{
		return myTYG;
	}
	public String getPosition()
	{
		return myPosition;
	}
	public ArrayList<String> getAssignments()
	{
		return myAssignments;
	}
	public String toString()
	{
		return getFirstN() + " " + getLastN();
	}

}
