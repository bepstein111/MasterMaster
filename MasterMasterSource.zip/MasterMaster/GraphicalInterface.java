import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import javax.swing.border.*;
import javax.swing.*;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
public class GraphicalInterface
{
	private static JFrame mainPage, info1, info2, info3, info4;
	final static JTextField peulot = new JTextField(), shiurim = new JTextField(), mBunks = new JTextField(), fBunks = new JTextField(), pcProg = new JTextField();
	final static JButton fileName = new JButton("Browse for file");
	private static Manager manager;
	private static Peulah[] peulotObjects;
	private static Shiur[] shiurObjects;
	private static Bunk[] maleBunkObjects, femaleBunkObjects;
	private static int pc;
	private static String finalFileName, finalNameOfFile;
	public static void main(String[] args)
	{
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
		    public void run() {
		        createAndShowGUI();
		    }
		});
		
	
		
	}
	private static void createAndShowGUI()
	{
		manager = new Manager(new MasterMaster());
		JFrame.setDefaultLookAndFeelDecorated(false);
		mainPage = new JFrame("NFTY Northeast Master Master Maker");
		mainPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainPage.getContentPane().setLayout(new BoxLayout(mainPage.getContentPane(), BoxLayout.PAGE_AXIS)); //what layout to use??
		
		JTextArea textArea = new JTextArea("             Thank you for using NFTY Northeast�s MasterMaster Maker! The MMM is fairly easy to use," +
				" but you should READ and pay attention to these instructions to make sure it works properly.\n\n             " +
				"First, you will need to create a simple txt file that the program will use to get its information." +
				" Create a spreadsheet (in Excel or Access) with all of the participants. It should have the following" +
				" information (and only this information) IN THIS ORDER: First column: first name, second column: last" +
				" name, third column: gender (�male� or �female� no abbreviations), fourth column: tyg, and fifth" +
				" column: position. For position, the only options should be �board�, �overall�, �pc�, and" +
				"�participant�, those exact words though case does not matter. Make sure all the pps have information" +
				" for all of these fields and that there are no spelling errors in position or gender. Once this is" +
				" complete, copy the data into notepad or another simple text editor and save as a .txt.\n\n             From this" +
				" point, the instructions for running the program are fairly self-explanatory. The program is" +
				" somewhat flexible, but it�s a simple program that is not designed to figure out exactly what the" +
				" user is thinking. When the program asks for a number, enter it in number form (1, 2, 3 etc). Only enter data that" +
				" makes sense. Though if things don�t work, never fear you can always run the program again. It is" +
				" possible you may come across a situation that the program is not designed to help you with, so" +
				" you�ll just have to manually create this in the final spreadsheet. For example, in the PC program," +
				" those officers that are not roving are given a �blank� assignment and need to be placed manually" +
				" after program execution.\n\n             The final product of the program is a number of text files: the Master" +
				" Master, a bunk roster, and attendance sheets for each peulah and shiur. Each text file (except" +
				" the bunk roster) is designed to be copied and pasted into Excel. Margins may need to be adjusted" +
				" in Excel. The group attendance sheets are ordered by position first (officers then overalls then" +
				" pcs then participants) and then by first name. The bunk lists are ordered by position and then" +
				" last name.\n\n             Brief overview on what the program does. For bunk assignments, the program will" +
				" fill the bunks to about an equal percentage of capacity. (For each gender) Officers are placed" +
				" one per bunk starting at the beginning of the list, and overalls are placed one per bunk starting" +
				" at the end of the list. Therefore it would be smart to enter bunks that you want an officer in" +
				" first. PCs are placed one per bunk starting in the middle and going back. For shiurim, officers" +
				" are placed individually from the beginning (group 1), and overalls from the back (last group)." +
				" Non-roving GLs will be made GLs of the groups, and the remaining officers/overalls will be placed" +
				" one each in groups as participants starting from the highest number and going down. The lists of" +
				" officers / overalls / pcs are shuffled before each placement randomizing it. All other placements" +
				" are completely random. You should LOOK OVER the MM especially the bunk assignments (officer /" +
				" overall / pc placement) to make sure it is satisfactory.");
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setEditable(false);
		textArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		JScrollPane instructions = new JScrollPane(textArea);
		instructions.setPreferredSize(new Dimension(620, 500));
		instructions.setVisible(true);
		instructions.setAutoscrolls(true);
		instructions.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20), BorderFactory.createLineBorder(Color.BLACK, 2)));
		
		JButton begin = new JButton("Continue");
		begin.setOpaque(true);
		begin.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e)
        	{
        		mainPage.dispose();
        	
        		acquireInfoOne();
                
        	}
        });
		begin.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED), BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        begin.setVisible(true);
        begin.setAlignmentX(JButton.CENTER_ALIGNMENT);
        
        JLabel spacer = new JLabel();
        spacer.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        spacer.setVisible(true);
        mainPage.getContentPane().add(instructions);
        mainPage.getContentPane().add(begin);
        mainPage.getContentPane().add(spacer);
        mainPage.pack();
        mainPage.setLocation(20,20);
        mainPage.setVisible(true);
        
	}
	private static void acquireInfoOne()
	{
		info1 = new JFrame("NFTY Northeast MMM - Stage One");
		info1.setLocation(20, 20);
        info1.getContentPane().setLayout(new GridLayout(7,2));
        
        peulot.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5), BorderFactory.createBevelBorder(1)));
        peulot.setPreferredSize(new Dimension(25, 20));

        shiurim.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5), BorderFactory.createBevelBorder(1)));
        shiurim.setPreferredSize(new Dimension(25,20));

        mBunks.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5), BorderFactory.createBevelBorder(1)));
        mBunks.setPreferredSize(new Dimension(25,20));

        fBunks.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5), BorderFactory.createBevelBorder(1)));
        fBunks.setPreferredSize(new Dimension(25, 20));

        pcProg.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5), BorderFactory.createBevelBorder(1)));
        pcProg.setPreferredSize(new Dimension(25,20));

		fileName.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				JFileChooser chooser = new JFileChooser();
				chooser.setDialogTitle("Select Input File");
				int returnVal = chooser.showDialog(info1, "Select File");
				if(returnVal == JFileChooser.APPROVE_OPTION)
				{
					File file = chooser.getSelectedFile();
					System.out.println(file.getPath());
					finalFileName = file.getAbsolutePath();
					finalNameOfFile = file.getName();
				}
			}

		});
        
        JLabel peulotT = new JLabel();
        peulotT.setPreferredSize(new Dimension(30, 30));
        peulotT.setText("Number of PEULOT:");
        peulotT.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        JLabel shiurimT = new JLabel();
        shiurimT.setText("Number of SHIURIM:");
        shiurimT.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        JLabel mBunksT = new JLabel();
        mBunksT.setText("Number of MALE BUNKS / ROOMS:");
        mBunksT.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        JLabel fBunksT = new JLabel();
        fBunksT.setText("Number of FEMALE BUNKS / ROOMS:");
        fBunksT.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        JLabel pcProgT = new JLabel();
        pcProgT.setText("Which program number is PC program?:");
        pcProgT.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        JLabel fileNameT = new JLabel();
        fileNameT.setText("Click to find input file:");
        fileNameT.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        peulot.setPreferredSize(new Dimension(10, 8));
        shiurim.setPreferredSize(new Dimension(20, 8));
        mBunks.setPreferredSize(new Dimension(20, 8));
        fBunks.setPreferredSize(new Dimension(20, 8));
        pcProg.setPreferredSize(new Dimension(20, 8));
        fileName.setPreferredSize(new Dimension(30, 8));
	    
        JButton cont = new JButton("Continue");
        cont.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e)
        	{
        		boolean readyToMoveOn = true;

        		try
        		{
        			System.out.println(Integer.parseInt(peulot.getText()) + " peulot.");
        			System.out.println(Integer.parseInt(shiurim.getText()) + " shiurim.");
        			System.out.println(Integer.parseInt(mBunks.getText()) + " male bunks.");
        			System.out.println(Integer.parseInt(fBunks.getText()) + " female bunks.");
        			System.out.println(Integer.parseInt(pcProg.getText()) + " is the number of PC prog.");
        			System.out.println("filename: " + fileName.getText() + finalFileName);
        		}
        		catch (NumberFormatException ex)
        		{
        			readyToMoveOn = false;
        			numbersOnlyDialog(1);
        		}
        		if (finalFileName == null)
        		{
        			readyToMoveOn = false;
        			selectFileDialog();
        		}
        		if (readyToMoveOn)
        		{
        			createConfirmDialog(peulot.getText(), shiurim.getText(), mBunks.getText(), fBunks.getText(), pcProg.getText(), finalNameOfFile);
        		}
        		
        	}
        });
		cont.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED), BorderFactory.createEmptyBorder(3, 3, 3, 3)));
        cont.setVisible(true);
        
        info1.getContentPane().add(peulotT);
        info1.getContentPane().add(peulot);
        info1.getContentPane().add(shiurimT);
        info1.getContentPane().add(shiurim);
        info1.getContentPane().add(mBunksT);
	    info1.getContentPane().add(mBunks);
	    info1.getContentPane().add(fBunksT);
	    info1.getContentPane().add(fBunks);
	    info1.getContentPane().add(pcProgT);
	    info1.getContentPane().add(pcProg);
	    info1.getContentPane().add(fileNameT);
	    info1.getContentPane().add(fileName);
	    info1.getContentPane().add(cont);
	    info1.pack();
	    info1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		info1.setVisible(true);
	}
	private static void acquireInfoTwo()
	{
		info2 = new JFrame();
		info2.setLayout(new FlowLayout());
		final JTextField[] pGroupNum = new JTextField[peulotObjects.length];
		final JTextField[] sGroupNum = new JTextField[shiurObjects.length];
		JLabel[] pGroupPrompt = new JLabel[peulotObjects.length];
		JLabel[] sGroupPrompt = new JLabel[shiurObjects.length];
		for (int i = 0; i < pGroupPrompt.length; i++)
		{
			pGroupPrompt[i] = new JLabel();
			pGroupPrompt[i].setText("Peulah " + (i + 1));
			pGroupNum[i] = new JTextField();
			pGroupNum[i].setPreferredSize(new Dimension(35, 23));
		}
		for (int i = 0; i < sGroupPrompt.length; i++)
		{
			sGroupPrompt[i] = new JLabel();
			sGroupPrompt[i].setText("Shiur " + (i + 1));
			sGroupNum[i] = new JTextField();
			sGroupNum[i].setPreferredSize(new Dimension(35, 23));
		}
		JPanel[] pRows = new JPanel[pGroupPrompt.length / 6 + 1];
		JPanel[] sRows = new JPanel[sGroupPrompt.length / 6 + 1];
		System.out.println("pRows.length: " + pRows.length);
		JPanel header = new JPanel();
		JLabel headerText = new JLabel();
		headerText.setText("Enter the number of groups for each of the Peulot / Shiurim:");
		headerText.setVisible(true);
		header.setVisible(true);
		info2.getContentPane().add(headerText);
		for (int panel = 0; panel < pRows.length; panel++)
		{
			pRows[panel] = new JPanel();
			for (int label = 0; label < 6 && panel * 6 + label < pGroupPrompt.length; label++)
			{
				pRows[panel].add(pGroupPrompt[panel * 6 + label]);
				pRows[panel].add(pGroupNum[panel * 6 + label]);
			}
			info2.getContentPane().add(pRows[panel]);
		}
		for (int panel = 0; panel < sRows.length; panel++)
		{
			sRows[panel] = new JPanel();
			for (int label = 0; label < 6 && panel * 6 + label < sGroupPrompt.length; label++)
			{
				sRows[panel].add(sGroupPrompt[panel * 6 + label]);
				sRows[panel].add(sGroupNum[panel * 6 + label]);
			}
			info2.getContentPane().add(sRows[panel]);
		}
		JPanel footer = new JPanel();
		JButton continu = new JButton("Continue");
		continu.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						boolean canAdvance = true;
						for (int i = 0; i < shiurObjects.length; i++)
						{
							try
							{
								shiurObjects[i] = new Shiur(Integer.parseInt(sGroupNum[i].getText()));
							}
							catch(NumberFormatException ex)
							{
								canAdvance = false;
								numbersOnlyDialog(1);
								break;
							}
						}
						for (int i = 0; i < peulotObjects.length; i++)
						{
							try
							{
								peulotObjects[i] = new Peulah(Integer.parseInt(pGroupNum[i].getText()), (pc == i + 1));
							}
							catch(NumberFormatException ex)
							{
								canAdvance = false;
								numbersOnlyDialog(1);
								break;
							}
						}
						if (!canAdvance)
							return;
						manager.getMM().setShiurim(shiurObjects);
						manager.getMM().setPeulot(peulotObjects);
						acquireInfoThree();
					}

				});
		footer.add(continu);
		info2.getContentPane().add(footer);
		info2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		info2.setPreferredSize(new Dimension(700, 500));
		info2.setLocation(20, 20);
		info2.pack();
		info2.setVisible(true);
	}
	private static void createConfirmDialog(String pLot, String shr, String mBunk, String fBunk, String pcPro, String fName)
	{
		final int numPlot = Integer.parseInt(pLot);
		final int numShiur = Integer.parseInt(shr);
		final int numMbunk = Integer.parseInt(mBunk);
		final int numFbunk = Integer.parseInt(fBunk);
		final int npc = Integer.parseInt(pcPro);
		final JDialog confirm = new JDialog();
		confirm.setTitle("Confirmation");
		confirm.setModal(true);
		confirm.setAlwaysOnTop(true);
		confirm.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		confirm.setLayout(new GridLayout(2, 1));
		confirm.setBackground(mainPage.getBackground());
		JTextArea info = new JTextArea();
		info.setBackground(confirm.getBackground());
		info.setEditable(false);
		info.setText("\n Are you sure?:\n\n Peulot:  " + pLot + "\t Female Bunks:  " + fBunk + "\n\n Shiurim:  " + shr + "\t PC Program:  #" + pcPro + "\n\n Male Bunks:  " + mBunk + "\t Filename:  " + fName);
		JButton yes = new JButton("YES");
		JButton no = new JButton("NO");
        yes.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e)
        	{
        		confirm.dispose();
        		info1.dispose();
        		peulotObjects = new Peulah[numPlot];
        		shiurObjects = new Shiur[numShiur];
        		maleBunkObjects = new Bunk[numMbunk];
        		femaleBunkObjects = new Bunk[numFbunk];
        		pc = npc;
        		try
        		{
        			manager.readInputFile(finalFileName);
        		}
        		catch (IOException exe)
        		{
        			System.out.println("Attention! Error in reading of file, please quit and run program again.");
        			System.out.println(exe.getMessage());
        		}
        		acquireInfoTwo();
        	}
        });
        no.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e)
        	{
        		confirm.dispose();
        	}
        });
        yes.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED), BorderFactory.createEmptyBorder(20, 40, 20, 40)));//, BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        no.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED), BorderFactory.createEmptyBorder(20, 40, 20, 40)));
        confirm.getContentPane().add(info);
        
        JPanel holder = new JPanel();
        holder.setLayout(new GridBagLayout());
        holder.add(yes);
        holder.add(no);
        holder.setBackground(confirm.getBackground());
        confirm.getContentPane().add(holder);
        confirm.setPreferredSize(new Dimension(270, 300));
        confirm.setLocation(20, 20);
        confirm.pack();
        confirm.setVisible(true);
       
	}
	private static void acquireInfoThree()
	{
		info2.dispose();
		info3 = new JFrame();
		info3.getContentPane().setLayout(new GridLayout(0, 1));
		info3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		info3.setTitle("Select ROVERS");
		JPanel instru = new JPanel();
		JLabel instruc = new JLabel();
		instruc.setText("Select rovers for each program using check boxes.");
		instru.add(instruc);
		info3.getContentPane().add(instru);
		final JPanel[] programRovers = new JPanel[manager.getMM().getPeulot().length];
		for (int i = 0; i < programRovers.length; i++)
		{
			programRovers[i] = new JPanel();
			programRovers[i].setLayout(new GridLayout(2, 0));
			for (int j = 0; j < manager.getMM().getGLs().size(); j++)
			{
				JCheckBox box = new JCheckBox(((Youth)manager.getMM().getGLs().get(j)).getFirstN() + " " + ((Youth)manager.getMM().getGLs().get(j)).getLastN());
				box.setSelected(false);
				programRovers[i].add(box);
			}
			programRovers[i].setBorder(BorderFactory.createTitledBorder("Peulah " + (i + 1)));
			info3.getContentPane().add(programRovers[i]);
		}

		JButton doneRovers = new JButton("Continue");
		doneRovers.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						Peulah[] thePeulot = manager.getMM().getPeulot();
						for (int i = 0; i < thePeulot.length; i++)
						{
							ArrayList<Youth> rovers = new ArrayList<Youth>();
							Component[] components = programRovers[i].getComponents();
							for (int j = 0; j < manager.getMM().getGLs().size(); j++)
							{
								if (((JCheckBox)components[j]).isSelected())
								{
									rovers.add(manager.getMM().getGLs().get(j));
								}
							}
							manager.getMM().getPeulot()[i].setRovers(rovers);
							System.out.println("Peulah " + (i + 1) + " rovers: " + rovers);
						}
						info3.dispose();
						acquireInfoFour();
					}

				});
		info3.getContentPane().add(doneRovers);
		info3.pack();
		info3.setVisible(true);
	}
	private static void acquireInfoFour()
	{
		info4 = new JFrame();
		info4.setLayout(new GridLayout(0, 1));
		info4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel header = new JPanel();
		JLabel header1 = new JLabel();
		header1.setText("Enter the name of the bunk in the first column, (MH1, KKC2, etc) and the max capacity in the 2nd");
		header.add(header1);
		info4.getContentPane().add(header);
		final JLabel[] bunkPrompts = new JLabel[maleBunkObjects.length + femaleBunkObjects.length];
		final JTextField[] bunkNames = new JTextField[bunkPrompts.length];
		final JTextField[] bunkCapacities = new JTextField[bunkPrompts.length];
		JPanel[] bunkContainers = new JPanel[bunkPrompts.length];
		for (int i = 0; i < bunkPrompts.length; i++)
		{
			bunkPrompts[i] = new JLabel();
			if (i < maleBunkObjects.length)
			{
				bunkPrompts[i].setText("Male bunk " + (i + 1));
			}
			else
			{
				bunkPrompts[i].setText("Female bunk " + (i - maleBunkObjects.length + 1));
			}
			bunkNames[i]= new JTextField();
			bunkNames[i].setPreferredSize(new Dimension(90, 20));
			bunkCapacities[i] = new JTextField();
			bunkCapacities[i].setPreferredSize(new Dimension(25, 20));
			bunkContainers[i] = new JPanel();
			bunkContainers[i].add(bunkPrompts[i]);
			bunkContainers[i].add(bunkNames[i]);
			bunkContainers[i].add(bunkCapacities[i]);
			info4.getContentPane().add(bunkContainers[i]);
		}
		JButton goOn = new JButton("Finish!");
		goOn.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						boolean canAdvance = true;
						double capacity;
						ArrayList<Bunk> mBunksAL = new ArrayList<Bunk>();
						ArrayList<Bunk> fBunksAL = new ArrayList<Bunk>();
						for (int i = 0; i < bunkPrompts.length; i++)
						{
							String name = bunkNames[i].getText();
							try
							{
								capacity = Double.parseDouble(bunkCapacities[i].getText());
							}
							catch (NumberFormatException ex)
							{
								numbersOnlyDialog(0);
								canAdvance = false;
								break;
							}
							
							if (i < maleBunkObjects.length)
							{
								maleBunkObjects[i] = new Bunk(name, capacity);
								mBunksAL.add(maleBunkObjects[i]);
							}
							else
							{
								femaleBunkObjects[i - maleBunkObjects.length] = new Bunk(name, capacity);
								fBunksAL.add(femaleBunkObjects[i - maleBunkObjects.length]);
							}
						}
						if (!canAdvance)
							return;
						manager.getMM().setMaleBunks(mBunksAL);
						manager.getMM().setFemaleBunks(fBunksAL);
						manager.assemble();
						
						File outputDirectory = null;
						JFileChooser chooser = new JFileChooser();
						chooser.setDialogTitle("Select Output Folder");
						chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
						int returnVal = chooser.showDialog(info1, "Select Output Folder");
						if(returnVal == JFileChooser.APPROVE_OPTION)
						{
							outputDirectory = chooser.getSelectedFile();
							System.out.println(outputDirectory.getPath());
						}
						
						try
						{
							manager.printFiles(outputDirectory);
						}
						catch (IOException danwalker)
						{
							System.out.println("IO Error with printing files.");
						}
						JDialog finished = new JDialog();
						JLabel finishedText = new JLabel();
						finishedText.setText("The program has finished! Look over the files and make any changes necessary. Click exit.");
						finishedText.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
						JPanel holderTemp = new JPanel();
						holderTemp.add(finishedText);
						JButton exitProgram = new JButton("Exit");
						exitProgram.addActionListener(new ActionListener()
							{
									public void actionPerformed(ActionEvent e)
									{
										System.exit(0);
										
									}

								});
						holderTemp.add(exitProgram);
						finished.add(holderTemp);
						finished.pack();
						finished.setAlwaysOnTop(true);
						finished.setModal(true);
						finished.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
						finished.setVisible(true);
					}

				});

		info4.getContentPane().add(goOn);
		info4.pack();
		info4.setVisible(true);
	}
	private static void numbersOnlyDialog(int condition)
	{
		final JDialog numbersOnly = new JDialog();
		numbersOnly.setTitle("Numbers Only!");
		JTextArea text = new JTextArea();
		if (condition == 0)
			text.setText("Please enter only whole numbers with digits for the second column(ex 1, 4, or 23 and not 1.5, four, or twenty-three");
		else
			text.setText("Please enter only whole numbers with digits (ex 1, 4, or 23 and not 1.5, four, or twenty-three");
		text.setLineWrap(true);
		text.setWrapStyleWord(true);
		text.setEditable(false);
		text.setBackground(numbersOnly.getBackground());
		text.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		JButton okay = new JButton("OK");
		okay.setHorizontalAlignment(JButton.CENTER);
        okay.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e)
        	{
        		numbersOnly.dispose();
        	}
        });
        numbersOnly.setPreferredSize(new Dimension(200, 135));
        numbersOnly.setResizable(false);
        numbersOnly.setModal(true);
        numbersOnly.setAlwaysOnTop(true);
        numbersOnly.setLayout(new BoxLayout(numbersOnly.getContentPane(), BoxLayout.PAGE_AXIS));
        numbersOnly.getContentPane().add(text);
        numbersOnly.getContentPane().add(okay);
        numbersOnly.pack();
        
        numbersOnly.setLocation(20, 20);
        numbersOnly.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        numbersOnly.setVisible(true);
	}
	private static void selectFileDialog()
	{
		final JDialog selectFile = new JDialog();
		selectFile.setTitle("Select Input File!");
		JTextArea text = new JTextArea();
		text.setText("Click the button 'Browse for file' in order to select the input file!");
		text.setLineWrap(true);
		text.setWrapStyleWord(true);
		text.setEditable(false);
		text.setBackground(selectFile.getBackground());
		text.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		JButton okay = new JButton("OK");
		okay.setHorizontalAlignment(JButton.CENTER);
        okay.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e)
        	{
        		selectFile.dispose();
        	}
        });
        selectFile.setPreferredSize(new Dimension(200, 135));
        selectFile.setResizable(false);
        selectFile.setModal(true);
        selectFile.setAlwaysOnTop(true);
        selectFile.setLayout(new BoxLayout(selectFile.getContentPane(), BoxLayout.PAGE_AXIS));
        selectFile.getContentPane().add(text);
        selectFile.getContentPane().add(okay);
        selectFile.pack();
        
        selectFile.setLocation(20, 20);
        selectFile.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        selectFile.setVisible(true);
	}
}
