import java.util.ArrayList;
public class Group
{
	private Youth myLeader;
	private ArrayList<Youth> myParticipants;
	private int myNumber;
	public Group(int number)
	{
		myNumber = number;
		myParticipants = new ArrayList<Youth>();
	}
	public void addMember(Youth toAdd)
	{
		myParticipants.add(toAdd);
	}
	public void setLeader(Youth leader)
	{
		myLeader = leader;
	}
	public ArrayList<Youth> getMembers()
	{
		return myParticipants;
	}
	public void notifyYouth()
	{
		if (myLeader != null)
			myLeader.addAssignment("GL" + myNumber);
		for (int i = 0; i < myParticipants.size(); i++)
		{
			myParticipants.get(i).addAssignment("" + myNumber);
		}
	}
}
