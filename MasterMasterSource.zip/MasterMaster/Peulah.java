import java.util.*;
public class Peulah
{
	private ArrayList<Group> myGroups;
	private ArrayList<Youth> myRovers;
	private boolean isPC;
	
	public Peulah(int groups, boolean pc)
	{
		myGroups = new ArrayList<Group>(groups);
		for (int i = 0; i < groups; i++)
		{
			myGroups.add(new Group(i + 1));
		}
		isPC = pc;
	}
	public void setRovers(ArrayList<Youth> rovers)
	{
		myRovers = rovers;
	}
	public ArrayList<Youth> getRovers()
	{
		return myRovers;
	}
	public ArrayList<Group> getGroups()
	{
		return myGroups;
	}
	public boolean isPC()
	{
		return isPC;
	}
	public void notifyYouth()
	{
		for (int i = 0; i < myRovers.size(); i++)
		{
			myRovers.get(i).addAssignment("Rover");
		}
		for (int i = 0; i < myGroups.size(); i++)
		{
			myGroups.get(i).notifyYouth();
		}
	}
	
}
