import java.util.ArrayList;
import java.io.*;
public class Manager
{
	private MasterMaster myMM;
	public Manager(MasterMaster aMasterMaster)
	{
		myMM = aMasterMaster;
	}
	public void readInputFile(String fileName) throws IOException
	{
		BufferedReader fileIn = new BufferedReader(new FileReader(fileName));
		String toProcess;
		ArrayList<Youth> officers, overalls, pcs, pps;
		officers = new ArrayList<Youth>();
		overalls = new ArrayList<Youth>();
		pcs = new ArrayList<Youth>();
		pps = new ArrayList<Youth>();
		
		while ((toProcess = fileIn.readLine()) != null)
		{
			if (toProcess.equals(""))
				continue;
			String firstName = toProcess.substring(0, toProcess.indexOf('\t'));
			toProcess = toProcess.substring(toProcess.indexOf('\t') + 1);
			String lastName = toProcess.substring(0, toProcess.indexOf('\t'));
			toProcess = toProcess.substring(toProcess.indexOf('\t') + 1);
			String gender = toProcess.substring(0, toProcess.indexOf('\t'));
			toProcess = toProcess.substring(toProcess.indexOf('\t') + 1);
			String tyg = toProcess.substring(0, toProcess.indexOf('\t'));
			String position = toProcess.substring(toProcess.indexOf('\t') + 1);
			

			if (position.length() >= 2 && position.substring(0, 2).equalsIgnoreCase("PC"))
				pcs.add(new Youth(firstName, lastName, gender, tyg, position));
			else if (position.length() >= 5 && position.substring(0, 5).equalsIgnoreCase("board"))
				officers.add(new Youth(firstName, lastName, gender, tyg, position));
			else if (position.length() >= 7 && position.substring(0, 7).equalsIgnoreCase("overall"))
				overalls.add(new Youth(firstName, lastName, gender, tyg, position));
			else if (position.length() >= 11 && position.substring(0, 11).equalsIgnoreCase("participant"))
				pps.add(new Youth(firstName, lastName, gender, tyg, position));
			else
			{
				System.out.print("READ INSTRUCTIONS ON FORMAT OF INPUT FILE AND MAKE SURE IT COMPLIES. PROGRAM WILL NOW EXIT, PLEASE RESTART AFTER THE INPUT FILE IS FIXED.");
				System.exit(0);
			}
		}
		fileIn.close();
		myMM.setOfficers(officers);
		myMM.setOveralls(overalls);
		ArrayList<Youth> gls = new ArrayList<Youth>();
		gls.addAll(officers);
		gls.addAll(overalls);
		myMM.setGLs(gls);
		myMM.setPCs(pcs);
		myMM.setPPs(pps);
	}
	public MasterMaster assemble()
	{
		ArrayList<Youth> ppPC = new ArrayList<Youth>();
		ppPC.addAll(myMM.getPCs());
		ppPC.addAll(myMM.getPPs());
		/*
		 * BUNK ASSEMBLY
		 */
		
		//males
		Bunk[] mBunks = new Bunk[myMM.getMaleBunks().size()];
		Bunk[] fBunks = new Bunk[myMM.getFemaleBunks().size()];
		for (int i = 0; i < mBunks.length; i++)
		{
			mBunks[i] = myMM.getMaleBunks().get(i);
		}
		for (int i = 0; i < fBunks.length; i++)
		{
			fBunks[i] = myMM.getFemaleBunks().get(i);
		}
		
		//place officers
		shuffle(myMM.getOfficers());
		
		int mbunkIndex = 0, fbunkIndex = 0;
		
		for (int officerIndex = 0; officerIndex < myMM.getOfficers().size(); officerIndex++)
		{
			if (mbunkIndex == myMM.getMaleBunks().size())
				mbunkIndex = 0;
			if (fbunkIndex == myMM.getFemaleBunks().size())
				fbunkIndex = 0;
			
			if (myMM.getOfficers().get(officerIndex).gender().equalsIgnoreCase("male")) //if the officer to add is male...
			{
				if (mBunks.length == 0)
				{
					myMM.getOfficers().get(officerIndex).addAssignment(" ");
					continue;
				}
					
				myMM.getMaleBunks().get(mbunkIndex).addBunker(myMM.getOfficers().get(officerIndex));
				mbunkIndex++;
			}
			else //if the officer to add is female...
			{
				if (fBunks.length == 0)
				{
					myMM.getOfficers().get(officerIndex).addAssignment(" ");
					continue;
				}
				myMM.getFemaleBunks().get(fbunkIndex).addBunker(myMM.getOfficers().get(officerIndex));
				fbunkIndex++;
			}
		}
		
		//place overalls
		shuffle(myMM.getOveralls());
		mbunkIndex = mBunks.length - 1;
		fbunkIndex = fBunks.length - 1;
		
		for (int overallIndex = 0; overallIndex < myMM.getOveralls().size(); overallIndex++)
		{
			if (mbunkIndex < 0)
				mbunkIndex = mBunks.length - 1;
			if (fbunkIndex < 0)
				fbunkIndex = fBunks.length - 1;
			
			if (myMM.getOveralls().get(overallIndex).gender().equalsIgnoreCase("male")) //if the overall to add is male...
			{
				if (mBunks.length == 0)
				{
					myMM.getOveralls().get(overallIndex).addAssignment(" ");
					continue;
				}
				myMM.getMaleBunks().get(mbunkIndex).addBunker(myMM.getOveralls().get(overallIndex));
				mbunkIndex--;
			}
			else //if the overall to add is female...
			{
				if (fBunks.length == 0)
				{
					myMM.getOveralls().get(overallIndex).addAssignment(" ");
					continue;
				}
				myMM.getFemaleBunks().get(fbunkIndex).addBunker(myMM.getOveralls().get(overallIndex));
				fbunkIndex--;
			}
		}
		mbunkIndex = mBunks.length / 2;
		fbunkIndex = fBunks.length / 2;
		//place PCs
		
		shuffle(myMM.getPCs());
		for (int pcIndex = 0; pcIndex < myMM.getPCs().size(); pcIndex++)
		{
			if (mbunkIndex == myMM.getMaleBunks().size())
				mbunkIndex = 0;
			if (fbunkIndex == myMM.getFemaleBunks().size())
				fbunkIndex = 0;
			
			if (myMM.getPCs().get(pcIndex).gender().equalsIgnoreCase("male")) //if the pc to add is male...
			{
				if (mBunks.length == 0)
				{
					myMM.getPCs().get(pcIndex).addAssignment(" ");
					continue;
				}
				myMM.getMaleBunks().get(mbunkIndex).addBunker(myMM.getPCs().get(pcIndex));
				mbunkIndex++;
			}
			else //if the pc to add is female...
			{
				if (fBunks.length == 0)
				{
					myMM.getPCs().get(pcIndex).addAssignment(" ");
					continue;
				}
				myMM.getFemaleBunks().get(fbunkIndex).addBunker(myMM.getPCs().get(pcIndex));
				fbunkIndex++;
			}
		}
		//place PPs
		shuffle(myMM.getPPs());
		sortBunks(mBunks);
		sortBunks(fBunks);
		for (int ppIndex = 0; ppIndex < myMM.getPPs().size(); ppIndex++)
		{
			if (myMM.getPPs().get(ppIndex).gender().equalsIgnoreCase("male"))
			{
				if (mBunks.length == 0)
				{
					myMM.getPPs().get(ppIndex).addAssignment(" ");
					continue;
				}
				mBunks[0].addBunker(myMM.getPPs().get(ppIndex));
				sortBunks(mBunks);
			}
			else //female
			{
				if (fBunks.length == 0)
				{
					myMM.getPPs().get(ppIndex).addAssignment(" ");
					continue;
				}
				fBunks[0].addBunker(myMM.getPPs().get(ppIndex));
				sortBunks(fBunks);
			}
		}
		
		

		/*
		 * SHIUR GROUP ASSEMBLY
		 */
		
		
		for (int shiur = 0; shiur < myMM.getShiurim().length; shiur++) //for each shiur
		{
			int shiurIndex = 0;
			shuffle(myMM.getOfficers());
			shuffle(myMM.getOveralls());

			shuffle(ppPC);
			Shiur thisShiur = myMM.getShiurim()[shiur];
			for (int officerIndex = 0; officerIndex < myMM.getOfficers().size(); officerIndex++) //place officers
			{
				if (shiurIndex == thisShiur.getGroups().size())
					shiurIndex = 0;

				thisShiur.getGroups().get(shiurIndex).addMember(myMM.getOfficers().get(officerIndex));
				shiurIndex++;
			}
			shiurIndex = 0;
			for (int overallIndex = 0; overallIndex < myMM.getOveralls().size(); overallIndex++) //place overalls
			{
				if (shiurIndex == thisShiur.getGroups().size())
					shiurIndex = 0;

				thisShiur.getGroups().get(thisShiur.getGroups().size() - shiurIndex - 1).addMember(myMM.getOveralls().get(overallIndex));
				shiurIndex++;
			}
			shiurIndex = 0;
			for (int ppPCIndex = 0; ppPCIndex < ppPC.size(); ppPCIndex++) //place PPs and PCs
			{
				if (shiurIndex == thisShiur.getGroups().size())
					shiurIndex = 0;

				thisShiur.getGroups().get(shiurIndex).addMember(ppPC.get(ppPCIndex));
				shiurIndex++;
			}
		}
		/*
		 * PEULAH GROUP ASSEMBLY
		 */
		for (int peulah = 0; peulah < myMM.getPeulot().length; peulah++)
		{
			shuffle(myMM.getGLs());
			System.out.println(myMM.getGLs());
			Peulah thisPeulah = myMM.getPeulot()[peulah];
			int glIndex = 0;
			if (!myMM.getPeulot()[peulah].isPC()) //if NOT PC program
			{
				for (int group = 0; group < thisPeulah.getGroups().size() && glIndex < myMM.getGLs().size(); group++) //group leaders
				{
					if (!thisPeulah.getRovers().contains(myMM.getGLs().get(glIndex)))
					{
						thisPeulah.getGroups().get(group).setLeader(myMM.getGLs().get(glIndex));
						System.out.println(myMM.getGLs().get(glIndex).toString() + " made GL of group " + (group + 1) + " in peulah " + (peulah + 1));
					}
					else
						group--;
					glIndex++;
				}
				
				glIndex = 0;
				int groupIndex = 0;
				for (int i = 0; i < myMM.getGLs().size() - thisPeulah.getGroups().size() - thisPeulah.getRovers().size(); i++) //GLs as PPs
				{
				
					Youth leader = myMM.getGLs().get(myMM.getGLs().size() - glIndex - 1);
					if (!thisPeulah.getRovers().contains(leader))
					{
						System.out.println(leader.toString() + " is not a rover in peulah " + (peulah + 1) + " and has been added as a PP to group " + (thisPeulah.getGroups().size() - groupIndex));
						
						thisPeulah.getGroups().get(thisPeulah.getGroups().size() - groupIndex - 1).addMember(leader);
						groupIndex++;
						if (groupIndex >= thisPeulah.getGroups().size())
						{
							groupIndex = 0;
						}
					}
					else
					{
						i--;
						System.out.println("It has been determined that " + leader.toString() + " is a rover in peulah " + (peulah + 1) + " and has been skipped in the GL as PP process.");
					}
					glIndex++;
					if (glIndex >= myMM.getGLs().size())
						glIndex = 0
						;
				}
				
				groupIndex = 0;
				shuffle(ppPC);
				for (int ppIndex = 0; ppIndex < ppPC.size(); ppIndex++)
				{
					if (groupIndex >= thisPeulah.getGroups().size())
						groupIndex = 0;
					thisPeulah.getGroups().get(groupIndex).addMember(ppPC.get(ppIndex));
					groupIndex++;
				}
			}
			else //PC program
			{
				shuffle(myMM.getPCs());
				for (int pc = 0; pc < myMM.getPCs().size(); pc++) //make PCs group leaders
				{
					if (pc >= thisPeulah.getGroups().size()) //if fewer groups in PC program than PCs
					{
						thisPeulah.getGroups().get((int)(Math.random() * thisPeulah.getGroups().size())).addMember(myMM.getPCs().get(pc));
						continue;
					}
					thisPeulah.getGroups().get(pc).setLeader(myMM.getPCs().get(pc));
					System.out.println(myMM.getPCs().get(pc).toString() + " made GL of group " + (pc + 1) + " in peulah " + (peulah + 1));
				}
				shuffle(myMM.getOveralls());
				for (int overall = 0; overall < myMM.getOveralls().size(); overall++) //add overalls from end
				{
					Youth ovrll = myMM.getOveralls().get(overall);
					if (!thisPeulah.getRovers().contains(ovrll))
						thisPeulah.getGroups().get(thisPeulah.getGroups().size() - overall - 1).addMember(ovrll);
				}
				shuffle(myMM.getPPs());
				int groupIndex = 0;
				for (int pp = 0; pp < myMM.getPPs().size(); pp++) //add pps
				{
					if (groupIndex >= thisPeulah.getGroups().size())
					{
						groupIndex = 0;
					}
					thisPeulah.getGroups().get(groupIndex).addMember(myMM.getPPs().get(pp));
					groupIndex++;
				}
			}
		}
		myMM.notifyYouth();
		return myMM;
	}
	public void printFiles(File outputDirectory) throws IOException
	{
		//bunk lists
		
		BufferedWriter bunkLists = new BufferedWriter(new FileWriter(outputDirectory.getAbsolutePath() + "\\" + "bunk lists.txt"));
		bunkLists.write("MALE BUNKS");
		bunkLists.newLine();
		for (int mbunk = 0; mbunk < myMM.getMaleBunks().size(); mbunk++)
		{
			bunkLists.write(myMM.getMaleBunks().get(mbunk).getName());
			bunkLists.newLine();
			ArrayList<Youth> bunkers = myMM.getMaleBunks().get(mbunk).getBunkers();
			alphabetizeCustom(bunkers, "last name");
			for (int bunker = 0; bunker < bunkers.size(); bunker++)
			{
				Youth bnker = bunkers.get(bunker);
				bunkLists.write(bnker.getFirstN() + " " + bnker.getLastN() + ", " + bnker.getTYG());
				if (!bnker.getPosition().equalsIgnoreCase("participant"))
					bunkLists.write(" (" + bnker.getPosition() + ")");
				bunkLists.newLine();
			}
			bunkLists.newLine();
			bunkLists.newLine();
		}
		bunkLists.write("FEMALE BUNKS");
		bunkLists.newLine();
		for (int fbunk = 0; fbunk < myMM.getFemaleBunks().size(); fbunk++)
		{
			bunkLists.write(myMM.getFemaleBunks().get(fbunk).getName());
			bunkLists.newLine();
			ArrayList<Youth> bunkers = myMM.getFemaleBunks().get(fbunk).getBunkers();
			alphabetizeCustom(bunkers, "last name");
			for (int bunker = 0; bunker < bunkers.size(); bunker++)
			{
				Youth bnker = bunkers.get(bunker);
				bunkLists.write(bnker.getFirstN() + " " + bnker.getLastN() + ", " + bnker.getTYG());
				if (!bnker.getPosition().equalsIgnoreCase("participant"))
					bunkLists.write(" (" + bnker.getPosition() + ")");
				bunkLists.newLine();
			}
			bunkLists.newLine();
			bunkLists.newLine();
		}
		bunkLists.close();
		//attendance sheets for peulot
		ArrayList<String>[] columns = new ArrayList[12];

		for (int peulah = 0; peulah < myMM.getPeulot().length; peulah++)
		{
			for (int i = 0; i < columns.length; i++)
			{
				columns[i] = new ArrayList<String>();
			}
			Peulah thisPeulah = myMM.getPeulot()[peulah];
			for (int group = 0; group < thisPeulah.getGroups().size(); group++)
			{
				Group thisGroup = thisPeulah.getGroups().get(group);
				alphabetizeCustom(thisGroup.getMembers(), "first name");
				if (group % 4 == 0)
				{
					columns[0].add("P" + (peulah + 1));
					columns[1].add("Group " + (group + 1));
					columns[2].add(" ");
					for (int youth = 0; youth < thisGroup.getMembers().size(); youth++)
					{
						Youth thisPP = thisGroup.getMembers().get(youth);
						columns[0].add(thisPP.getFirstN());
						columns[1].add(thisPP.getLastN());
						columns[2].add(thisPP.getTYG());
					}
					columns[0].add(" ");
					columns[1].add(" ");
					columns[2].add(" ");
				}
				else if (group % 4 == 1)
				{
					columns[3].add("P" + (peulah + 1));
					columns[4].add("Group " + (group + 1));
					columns[5].add(" ");
					for (int youth = 0; youth < thisGroup.getMembers().size(); youth++)
					{
						Youth thisPP = thisGroup.getMembers().get(youth);
						columns[3].add(thisPP.getFirstN());
						columns[4].add(thisPP.getLastN());
						columns[5].add(thisPP.getTYG());
					}
					columns[3].add(" ");
					columns[4].add(" ");
					columns[5].add(" ");
				}
				else if (group % 4 == 2)
				{
					columns[6].add("P" + (peulah + 1));
					columns[7].add("Group " + (group + 1));
					columns[8].add(" ");
					for (int youth = 0; youth < thisGroup.getMembers().size(); youth++)
					{
						Youth thisPP = thisGroup.getMembers().get(youth);
						columns[6].add(thisPP.getFirstN());
						columns[7].add(thisPP.getLastN());
						columns[8].add(thisPP.getTYG());
					}
					columns[6].add(" ");
					columns[7].add(" ");
					columns[8].add(" ");
				}
				else
				{
					columns[9].add("P" + (peulah + 1));
					columns[10].add("Group " + (group + 1));
					columns[11].add(" ");
					for (int youth = 0; youth < thisGroup.getMembers().size(); youth++)
					{
						Youth thisPP = thisGroup.getMembers().get(youth);
						columns[9].add(thisPP.getFirstN());
						columns[10].add(thisPP.getLastN());
						columns[11].add(thisPP.getTYG());
					}
					columns[9].add(" ");
					columns[10].add(" ");
					columns[11].add(" ");
				}
			}
			BufferedWriter attendanceSheet = new BufferedWriter(new FileWriter(outputDirectory.getAbsolutePath() + "\\" + "attendencePeulah" + (peulah + 1) + ".txt"));
			int iterator = 0;
			boolean done = false;
			while(!done)
			{
				done = true;
				for (int i = 0; i < columns.length; i++)
				{
					if (iterator < columns[i].size())
					{
						done = false;
						attendanceSheet.write(columns[i].get(iterator) + "\t");
					}
					else
					{
						attendanceSheet.write(" \t");
					}
				}
				attendanceSheet.newLine();
				iterator++;
			}
			attendanceSheet.close();
		}
		//attendance for shiurim, same exact method as for peulot, only change in name. copy and paste, ugly I know
		for (int shiur = 0; shiur < myMM.getShiurim().length; shiur++)
		{
			for (int i = 0; i < columns.length; i++)
			{
				columns[i] = new ArrayList<String>();
			}
			Shiur thisShiur = myMM.getShiurim()[shiur];
			for (int group = 0; group < thisShiur.getGroups().size(); group++)
			{
				Group thisGroup = thisShiur.getGroups().get(group);
				alphabetizeCustom(thisGroup.getMembers(), "first name");
				if (group % 4 == 0)
				{
					columns[0].add("S" + (shiur + 1));
					columns[1].add("Group " + (group + 1));
					columns[2].add(" ");
					for (int youth = 0; youth < thisGroup.getMembers().size(); youth++)
					{
						Youth thisPP = thisGroup.getMembers().get(youth);
						columns[0].add(thisPP.getFirstN());
						columns[1].add(thisPP.getLastN());
						columns[2].add(thisPP.getTYG());
					}
					columns[0].add(" ");
					columns[1].add(" ");
					columns[2].add(" ");
				}
				else if (group % 4 == 1)
				{
					columns[3].add("S" + (shiur + 1));
					columns[4].add("Group " + (group + 1));
					columns[5].add(" ");
					for (int youth = 0; youth < thisGroup.getMembers().size(); youth++)
					{
						Youth thisPP = thisGroup.getMembers().get(youth);
						columns[3].add(thisPP.getFirstN());
						columns[4].add(thisPP.getLastN());
						columns[5].add(thisPP.getTYG());
					}
					columns[3].add(" ");
					columns[4].add(" ");
					columns[5].add(" ");
				}
				else if (group % 4 == 2)
				{
					columns[6].add("S" + (shiur + 1));
					columns[7].add("Group " + (group + 1));
					columns[8].add(" ");
					for (int youth = 0; youth < thisGroup.getMembers().size(); youth++)
					{
						Youth thisPP = thisGroup.getMembers().get(youth);
						columns[6].add(thisPP.getFirstN());
						columns[7].add(thisPP.getLastN());
						columns[8].add(thisPP.getTYG());
					}
					columns[6].add(" ");
					columns[7].add(" ");
					columns[8].add(" ");
				}
				else
				{
					columns[9].add("S" + (shiur + 1));
					columns[10].add("Group " + (group + 1));
					columns[11].add(" ");
					for (int youth = 0; youth < thisGroup.getMembers().size(); youth++)
					{
						Youth thisPP = thisGroup.getMembers().get(youth);
						columns[9].add(thisPP.getFirstN());
						columns[10].add(thisPP.getLastN());
						columns[11].add(thisPP.getTYG());
					}
					columns[9].add(" ");
					columns[10].add(" ");
					columns[11].add(" ");
				}
			}
			BufferedWriter attendanceSheet = new BufferedWriter(new FileWriter(outputDirectory.getAbsolutePath() + "\\" + "attendenceShiur" + (shiur + 1) + ".txt"));
			int iterator = 0;
			boolean done = false;
			while(!done)
			{
				done = true;
				for (int i = 0; i < columns.length; i++)
				{
					if (iterator < columns[i].size())
					{
						done = false;
						attendanceSheet.write(columns[i].get(iterator) + "\t");
					}
					else
					{
						attendanceSheet.write(" \t");
					}
				}
				attendanceSheet.newLine();
				iterator++;
			}
			attendanceSheet.close();
		}
		//MASTER MASTER
		BufferedWriter masterMaster = new BufferedWriter(new FileWriter(outputDirectory.getAbsolutePath() + "\\" + "MasterMaster.txt"));
		masterMaster.write("First\tLast\tTYG\tPosition\tBunk\t");
		for (int peulah = 0; peulah < myMM.getPeulot().length; peulah++)
		{
			masterMaster.write("P" + (peulah + 1) + "\t");
		}
		for (int shiur = 0; shiur < myMM.getShiurim().length; shiur++)
		{
			masterMaster.write("S" + (shiur + 1) + "\t");
		}
		masterMaster.newLine();
		for (int officer = 0; officer < myMM.getOfficers().size(); officer++)
		{
			Youth offcr = myMM.getOfficers().get(officer);
			masterMaster.write(offcr.getFirstN() + "\t" + offcr.getLastN() + "\t" + offcr.getTYG() + "\t" + offcr.getPosition() + "\t");
			printAssignments(masterMaster, offcr.getAssignments());
			masterMaster.newLine();
		}
		for (int overall = 0; overall < myMM.getOveralls().size(); overall++)
		{
			Youth ovrll = myMM.getOveralls().get(overall);
			masterMaster.write(ovrll.getFirstN() + "\t" + ovrll.getLastN() + "\t" + ovrll.getTYG() + "\t" + ovrll.getPosition() + "\t");
			printAssignments(masterMaster, ovrll.getAssignments());
			masterMaster.newLine();
		}
		for (int pc = 0; pc < myMM.getPCs().size(); pc++)
		{
			Youth pcoord = myMM.getPCs().get(pc);
			masterMaster.write(pcoord.getFirstN() + "\t" + pcoord.getLastN() + "\t" + pcoord.getTYG() + "\t" + pcoord.getPosition() + "\t");
			printAssignments(masterMaster, pcoord.getAssignments());
			System.out.println(pcoord);
			System.out.println(pcoord.getAssignments());
			masterMaster.newLine();
		}
		for (int pp = 0; pp < myMM.getPPs().size(); pp++)
		{
			Youth ppant = myMM.getPPs().get(pp);
			masterMaster.write(ppant.getFirstN() + "\t" + ppant.getLastN() + "\t" + ppant.getTYG() + "\t" + ppant.getPosition() + "\t");
			printAssignments(masterMaster, ppant.getAssignments());
			masterMaster.newLine();
		}
		masterMaster.close();
	}
	private void sortBunks(Bunk[] toSort)
	{
		//selection sort
		int sortedIndex = 0, minIndex = 0;
		double minValue = 999;
		
		while (sortedIndex < toSort.length - 1) //the last remaining item will, by POE, be in right position
		{
			minValue = 999;
			for (int i = sortedIndex; i < toSort.length; i++)
			{
				if (toSort[i].getFillPercent() < minValue)
				{
					minValue = toSort[i].getFillPercent();
					minIndex = i;
				}
			}
		
			//switch lowest into next sorted position
			Bunk temp = toSort[sortedIndex];
			toSort[sortedIndex] = toSort[minIndex];
			toSort[minIndex] = temp;
			sortedIndex++;
		}
		
	}
	private <E> void shuffle(ArrayList<E> unShuffled)
	{
		ArrayList<E> shuffled = new ArrayList<E>(unShuffled.size());
		while (unShuffled.size() != 0)
		{
			int randomIndex = (int)(Math.random() * unShuffled.size());
			shuffled.add(unShuffled.get(randomIndex));
			unShuffled.remove(randomIndex);
		}
		for (int i = 0; i < shuffled.size(); i++)
		{
			unShuffled.add(shuffled.get(i));
		}
	}
	private void printAssignments(BufferedWriter masterMaster, ArrayList<String> toPrint) throws IOException
	{
		for (int i = 0; i < toPrint.size(); i++)
		{
			masterMaster.write(toPrint.get(i) + "\t");
		}
	}
	private void alphabetizeCustom(ArrayList<Youth> toAlpha, String field)
	{
		//find officers
		//find overalls
		//find pcs
		//alphabetize rest.
		ArrayList<Youth> officers = new ArrayList<Youth>();
		ArrayList<Youth> overalls = new ArrayList<Youth>();
		ArrayList<Youth> pcs = new ArrayList<Youth>();
		ArrayList<Youth> pps = new ArrayList<Youth>();

		for (int i = 0; i < toAlpha.size(); i++)
		{
			Youth current = toAlpha.get(i);
			if (current.getPosition().equalsIgnoreCase("board"))
			{
				officers.add(current);
				toAlpha.remove(current);
			}
			else if (current.getPosition().equalsIgnoreCase("overall"))
			{
				overalls.add(current);
				toAlpha.remove(current);
			}
			else if (current.getPosition().equalsIgnoreCase("PC"))
			{
				pcs.add(current);
				toAlpha.remove(current);
			}
			else
			{
				pps.add(current);
				toAlpha.remove(current);
			}
			i--;
		}
		alphabetize(officers, field);
		alphabetize(overalls, field);
		alphabetize(pcs, field);
		alphabetize(pps, field);
		toAlpha.addAll(officers);
		toAlpha.addAll(overalls);
		toAlpha.addAll(pcs);
		toAlpha.addAll(pps);
		
		
	}
	private void alphabetize(ArrayList<Youth> toAlpha, String field)
	{
		ArrayList<Youth> alphabetized = new ArrayList<Youth>();
		if (field.equalsIgnoreCase("first name"))
		{
			String minValue; 
			int minIndex;
			while (toAlpha.size() > 0)
			{
				minIndex = 0;
				minValue = toAlpha.get(0).getFirstN().toLowerCase();
				for (int i = 0; i < toAlpha.size(); i++)
				{
					if (toAlpha.get(i).getFirstN().toLowerCase().compareTo(minValue) < 0)
					{
						minValue = toAlpha.get(i).getFirstN().toLowerCase();
						minIndex = i;
					}
				}
				alphabetized.add(toAlpha.get(minIndex));
				toAlpha.remove(toAlpha.get(minIndex));
			}
			for (int i = 0; i < alphabetized.size(); i++)
			{
				toAlpha.add(alphabetized.get(i));
			}

			
			
		}
		else if (field.equalsIgnoreCase("last name"))
		{
			String minValue; 
			int minIndex;
			while (toAlpha.size() > 0)
			{
				minIndex = 0;
				minValue = toAlpha.get(0).getLastN().toLowerCase();
				for (int i = 0; i < toAlpha.size(); i++)
				{
					if (toAlpha.get(i).getLastN().toLowerCase().compareTo(minValue) < 0)
					{
						minValue = toAlpha.get(i).getLastN().toLowerCase();
						minIndex = i;
					}
				}
				alphabetized.add(toAlpha.get(minIndex));
				toAlpha.remove(toAlpha.get(minIndex));
			}
			for (int i = 0; i < alphabetized.size(); i++)
			{
				toAlpha.add(alphabetized.get(i));
			}
		}
	}
	public MasterMaster getMM()
	{
		return myMM;
	}
}
