import java.util.ArrayList;
public class Bunk
{
	private ArrayList<Youth> myBunkers;
	private double myCapacity;
	private String myName;
	public Bunk(String aName, double capacity)
	{
		myName = aName;
		myCapacity = capacity;
		myBunkers = new ArrayList<Youth>();
	}
	public void addBunker(Youth toAdd)
	{
		myBunkers.add(toAdd);
	}
	public String getName()
	{
		return myName;
	}
	public double getFillPercent()
	{
		return myBunkers.size() / myCapacity;
	}
	public int compareFill(Bunk other)
	{
		if (getFillPercent() < other.getFillPercent())
			return -1;
		if (getFillPercent() == other.getFillPercent())
			return 0;
		return 1;
	}
	public ArrayList<Youth> getBunkers()
	{
		return myBunkers;
	}
	public void notifyYouth()
	{
		for (int i = 0; i < myBunkers.size(); i++)
		{
			myBunkers.get(i).addAssignment(myName);
		}
	}
}
