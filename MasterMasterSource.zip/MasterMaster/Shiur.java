import java.util.ArrayList;
public class Shiur
{
	private ArrayList<Group> myGroups;
	public Shiur(int groups)
	{
		myGroups = new ArrayList<Group>(groups);
		for (int i = 0; i < groups; i++)
		{
			myGroups.add(new Group(i + 1));
		}
	}
	public ArrayList<Group> getGroups()
	{
		return myGroups;
	}
	public void notifyYouth()
	{
		for (int i = 0; i < myGroups.size(); i++)
		{
			myGroups.get(i).notifyYouth();
		}
	}
}
