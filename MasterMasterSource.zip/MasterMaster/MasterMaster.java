import java.util.ArrayList;
public class MasterMaster
{
	private ArrayList<Youth> myPCs, myGLs, myPPs, myOfficers, myOveralls;
	private ArrayList<Bunk> myMaleBunks, myFemaleBunks;
	private Peulah[] myPeulot;
	private Shiur[] myShiurim;
	public void setPeulot(Peulah[] peulot)
	{
		myPeulot = peulot;
	}
	public void setShiurim(Shiur[] shiurim)
	{
		myShiurim = shiurim;
	}
	public void setMaleBunks(ArrayList<Bunk> bunks)
	{
		myMaleBunks = bunks;
	}
	public void setFemaleBunks(ArrayList<Bunk> bunks)
	{
		myFemaleBunks = bunks;
	}
	public void setOfficers(ArrayList<Youth> officers)
	{
		myOfficers = officers;
	}
	public void setOveralls(ArrayList<Youth> overalls)
	{
		myOveralls = overalls;
	}
	public void setGLs(ArrayList<Youth> gls)
	{
		myGLs = gls;
	}
	public void setPCs(ArrayList<Youth> pcs)
	{
		myPCs = pcs;
	}
	public void setPPs(ArrayList<Youth> pps)
	{
		myPPs = pps;
	}
	
	public ArrayList<Bunk> getMaleBunks()
	{
		return myMaleBunks;
	}
	public ArrayList<Bunk> getFemaleBunks()
	{
		return myFemaleBunks;
	}
	public Peulah[] getPeulot()
	{
		return myPeulot;
	}
	public Shiur[] getShiurim()
	{
		return myShiurim;
	}
	public ArrayList<Youth> getOfficers()
	{
		return myOfficers;
	}
	public ArrayList<Youth> getOveralls()
	{
		return myOveralls;
	}
	public ArrayList<Youth> getGLs()
	{
		return myGLs;
	}
	public ArrayList<Youth> getPCs()
	{
		return myPCs;
	}
	public ArrayList<Youth> getPPs()
	{
		return myPPs;
	}
	public void notifyYouth() //tells bunks, peulot, and shiurim to notify the youth contained in their groups, ie add Strings representing each assignment
	{
		for (int mbunk = 0; mbunk < myMaleBunks.size(); mbunk++)
		{
			myMaleBunks.get(mbunk).notifyYouth();
		}
		for (int fbunk = 0; fbunk < myFemaleBunks.size(); fbunk++)
		{
			myFemaleBunks.get(fbunk).notifyYouth();
		}
		for (int peulah = 0; peulah < myPeulot.length; peulah++)
		{
			myPeulot[peulah].notifyYouth();
			if (myPeulot[peulah].isPC()) //add blank for non-roving officers in PC program to be added MANUALLY after program completion
			{
				for (int officer = 0; officer < myOfficers.size(); officer++)
				{
					if (!myPeulot[peulah].getRovers().contains(myOfficers.get(officer)))
						myOfficers.get(officer).addAssignment(" ");
				}
			}
		}
		for (int shiur = 0; shiur < myShiurim.length; shiur++)
		{
			myShiurim[shiur].notifyYouth();
		}
	}
}
